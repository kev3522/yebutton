Hi!

Open cmd/terminal and run 'python browser.py' in the corresponding directory.
When it spits out a local address, paste that into a browser and enjoy!